package com.stocks.databaseService.resource;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stocks.databaseService.model.Quote;
import com.stocks.databaseService.model.Quotes;



@RestController
@RequestMapping("/rest/db")
public class DbserviceController {
	
	List<HashMap<String, Quotes>> quotesPairList =new ArrayList<HashMap<String, Quotes>>();
	
	List<Quotes> quotesPair =new ArrayList<>();
	/*HashMap<String, Quotes> returnQuotes =new HashMap<>();*/
	
	
/*	 @PostMapping("/add")
    public List<HashMap<String, String>> add(@RequestBody final HashMap<String, String> quote) {
		 
		 quotes.add(quote); cv

//        quotes.stream()
//                .map(quote -> new Quote(quotes.getUserName(), quote))
//                .forEach(quote -> quotesRepository.save(quote));
        return quotes;
    }*/
	    @GetMapping("/{username}")
	    public List<String> getQuotes(@PathVariable("username") final String username) {

	        return getQuotesByUserName(username);
	    }
	    
	    @GetMapping("/all")
	    public List<Quotes> getQuotes() {

	        return quotesPair;
	    }

	    @PostMapping("/add")
	    public List<String> add(@RequestBody final Quotes quotes) {
	    	//quotesPair.clear();
/*	    	HashMap<String, Quotes> value = new HashMap<String, Quotes>();
	    	value.put(quotes.getUserName(), new Quotes(quotes.getUserName(), quotes.getQuotes()));
	    	quotesPairList.add(value);*/
	    	quotesPair.add(new Quotes(quotes.getUserName(),quotes.getQuotes()));

	      /*  quotes.getQuotes()
	                .stream()
	                .map(quote -> new Quote(quotes.getUserName(), quote))
	                .forEach( quote -> quotesPairList.addAll((Collection<? extends HashMap<String, Quote>>) quote));*/
	    	
	        return getQuotesByUserName(quotes.getUserName());
	    }


	  /*  @PostMapping("/delete/{username}")
	    public List<String> delete(@PathVariable("username") final String username) {

	        List<Quote> quotes = quotesRepository.findByUserName(username);
	        quotesRepository.delete((Quote) quotes);

	        return getQuotesByUserName(username);
	    }*/


	    @SuppressWarnings("unchecked")
		private List<String> getQuotesByUserName(@PathVariable("username") String username) {
	    	
	    	/*return (HashMap<String, List<String>>) quotesPairList.stream()
								    				.filter(quote-> quote.containsKey(username))
								    				.map(quote-> quote.get(username))
								    				.collect(Collectors.toMap(
								    							Quotes::getUserName,
								    							Quotes::getQuotes));*/
	    	
	    	return  quotesPair.stream()
	    				.filter(quote -> quote.getUserName().equals(username) )
	    				.findFirst().get().getQuotes();
	    				/*.map(Quotes::getQuotes)
	    				.collect(Collectors.t);*/
	    				//.findFirst().get();
	    				//.distinct();
	    				//.map(quote -> quote.get(username))
	    				//.collect(Collectors.toList());
	    				//.map(quote -> quote.get(username))
	
	    }


}
